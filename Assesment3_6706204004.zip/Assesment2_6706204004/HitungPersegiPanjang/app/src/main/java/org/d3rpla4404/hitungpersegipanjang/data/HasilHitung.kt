package org.d3rpla404.hitungpersegipanjang.data

data class HasilHitung(
    val hasil: Float,
    val hasil2 : Float
)